(() => {
  if (typeof document !== "undefined") document.documentElement.classList.add("js-motion");
  const PUBLICATIONS = [{"title": "Die übersehene Rotation", "description": "Die 2024 wiederaufgenommene Homepage und die Broschüre zur Frage, welche Rolle Rotation in physikalischen Deutungen spielt.", "category": "Aktuell", "year": "2024", "url": "/Test/publikationen/die-uebersehene-rotation/", "categories": ["aktuell", "relativitaet", "kosmologie"]}, {"title": "Als der Urknall Mode war", "description": "Ein rückblickend erzähltes Buch über das Urknallmodell, seine Popularität und die Frage, wie aus Deutungen scheinbare Gewissheiten werden.", "category": "Kosmologie", "year": "2005", "url": "/Test/publikationen/als-der-urknall-mode-war/", "categories": ["kosmologie"]}, {"title": "Das Rätsel der Dunklen Materie", "description": "Über die fehlende Masse in Galaxien, alternative Deutungen und die Frage, wie zwingend die Annahme Dunkler Materie ist.", "category": "Kosmologie", "year": "2005", "url": "/Test/publikationen/das-raetsel-der-dunklen-materie/", "categories": ["kosmologie"]}, {"title": "Physik von einem andern Stern", "description": "Eine kritische Auseinandersetzung mit kosmologischen Deutungen, Beobachtung und der Grenze zwischen Modell und physischer Wirklichkeit.", "category": "Kosmologie", "year": "Archiv", "url": "/Test/publikationen/physik-von-einem-andern-stern/", "categories": ["kosmologie"]}, {"title": "Weltbild-Wunder", "description": "Über Wunderbegriffe, Multiversen, Urknallmodelle und die Frage, wann mathematische Möglichkeit zur physikalischen Behauptung wird.", "category": "Wissenschaftskritik", "year": "2008", "url": "/Test/publikationen/weltbild-wunder/", "categories": ["wissenschaftskritik"]}, {"title": "Der blinde Beobachter", "description": "Über blinde Flecken in Wahrnehmung, Wissenschaft und Weltbildern - und darüber, wie Beobachter ihre eigenen Voraussetzungen übersehen können.", "category": "Erkenntniskritik", "year": "Archiv", "url": "/Test/publikationen/der-blinde-beobachter/", "categories": ["erkenntniskritik"]}, {"title": "Vergeistigte Physik", "description": "Eine umfangreiche Kritik daran, Natur durch mathematische Konstruktionen zu beschreiben, ohne zwischen Modell und Gegenstand ausreichend zu unterscheiden.", "category": "Wissenschaftskritik", "year": "2010", "url": "/Test/publikationen/vergeistigte-physik/", "categories": ["wissenschaftskritik"]}, {"title": "Die Lichtuhr im Dunkel der Mathematik", "description": "Gedanken zur Lichtuhr und zur mathematischen Interpretation relativistischer Effekte.", "category": "Relativität", "year": "Archiv", "url": "/Test/publikationen/die-lichtuhr-im-dunkel-der-mathematik/", "categories": ["relativitaet"]}, {"title": "\"Elvis lebt!\"", "description": "Eine pointierte Kritik an spekulativen Aussagen, die durch wissenschaftliche Sprache und institutionelle Autorität an Plausibilität gewinnen.", "category": "Wissenschaftskritik", "year": "Archiv", "url": "/Test/publikationen/elvis-lebt/", "categories": ["wissenschaftskritik"]}, {"title": "Orakel Einstein", "description": "Zwei Texte über Deutungen der Relativitätstheorie, widersprüchliche Aussagen und den Umgang mit Autorität in der Physik.", "category": "Relativität", "year": "2016", "url": "/Test/publikationen/orakel-einstein/", "categories": ["relativitaet"]}, {"title": "Fehlerproduktion in der Relativitätstheorie", "description": "Eine Auseinandersetzung mit ausgewählten Argumentationsmustern und Interpretationen in der Relativitätstheorie.", "category": "Relativität", "year": "Archiv", "url": "/Test/publikationen/fehlerproduktion-relativitaetstheorie/", "categories": ["relativitaet"]}, {"title": "Die Logik des Gesehenen versus die Logik des Physischen", "description": "Über den Unterschied zwischen dem, was eine Darstellung oder Beobachtung zeigt, und dem, was daraus physisch geschlossen werden darf.", "category": "Erkenntniskritik", "year": "Archiv", "url": "/Test/publikationen/logik-des-gesehenen-und-physischen/", "categories": ["erkenntniskritik"]}, {"title": "Gehen bewegte Uhren langsamer?", "description": "Eine kritische Betrachtung des bekannten Satzes \"Bewegte Uhren gehen langsamer\" anhand von Licht- und Wasseruhren.", "category": "Relativität", "year": "Archiv", "url": "/Test/publikationen/gehen-bewegte-uhren-langsamer/", "categories": ["relativitaet"]}, {"title": "Relativität und Kosinus", "description": "Ein Buchfragment zur These, die Lorentztransformation könne als Korrektur eines Beobachtungs- oder Verzerrungswinkels betrachtet werden.", "category": "Relativität", "year": "2011", "url": "/Test/publikationen/relativitaet-und-kosinus/", "categories": ["relativitaet"]}, {"title": "Pistolenexperiment: Geschoss- und Lichtgeschwindigkeit", "description": "Ein Gedankenexperiment zum Vergleich von Geschoss- und Lichtgeschwindigkeit und zu den Grenzen solcher Analogien.", "category": "Relativität", "year": "Archiv", "url": "/Test/publikationen/pistolenexperiment-geschwindigkeitsvergleich/", "categories": ["relativitaet"]}];

  const normalizeText = (value = "") => String(value)
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("de")
    .replace(/[„“"']/g, "")
    .replace(/\s+/g, " ")
    .trim();

  const matchesPublication = (publication, query = "", category = "alle") => {
    const q = normalizeText(query);
    const categories = publication.categories || [];
    const categoryMatch = category === "alle" || categories.includes(category);
    const haystack = normalizeText(
      [publication.title, publication.description, publication.category, publication.year].join(" ")
    );
    if (!categoryMatch) return false;
    if (!q) return true;
    if (haystack.includes(q)) return true;

    // Tokenbasierte, tolerante Suche: "dunkle materie" findet auch "Dunklen Materie".
    const hayTokens = haystack.split(/[^a-z0-9äöüß]+/).filter(Boolean);
    const queryTokens = q.split(/[^a-z0-9äöüß]+/).filter(Boolean);
    return queryTokens.every(token =>
      hayTokens.some(word => word === token || word.startsWith(token) || token.startsWith(word))
    );
  };

  globalThis.KGArchive = { normalizeText, matchesPublication, publications: PUBLICATIONS };

  if (typeof document === "undefined") return;

  const qs = (selector, root = document) => root.querySelector(selector);
  const qsa = (selector, root = document) => [...root.querySelectorAll(selector)];

  // Mobile navigation
  const menuButton = qs("[data-menu]");
  const nav = qs("[data-nav]");
  if (menuButton && nav) {
    menuButton.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      menuButton.setAttribute("aria-expanded", String(open));
    });
    qsa("a", nav).forEach(link => link.addEventListener("click", () => {
      nav.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    }));
  }

  // Index archive filters and search
  const archiveSearch = qs("[data-search]");
  const archiveItems = qsa("[data-publication]");
  const archiveFilters = qsa("[data-filter]");
  const archiveEmpty = qs("[data-empty]");
  const resultCount = qs("[data-result-count]");
  const searchReset = qs("[data-search-reset]");
  const resetFilters = qs("[data-reset-filters]");
  let archiveCategory = "alle";

  const syncArchiveUrl = () => {
    if (!archiveItems.length) return;
    const params = new URLSearchParams(location.search);
    const q = archiveSearch?.value.trim() || "";
    if (archiveCategory !== "alle") params.set("thema", archiveCategory);
    else params.delete("thema");
    if (q) params.set("q", q);
    else params.delete("q");
    const next = location.pathname + (params.toString() ? "?" + params.toString() : "") + "#publikationen";
    history.replaceState(null, "", next);
  };

  const applyArchive = (updateUrl = true) => {
    if (!archiveItems.length) return;
    const q = archiveSearch?.value || "";
    let shown = 0;

    archiveItems.forEach(item => {
      const publication = {
        title: qs("h3", item)?.textContent || "",
        description: qs(".pub-main p", item)?.textContent || "",
        category: qs(".pub-meta span", item)?.textContent || "",
        year: qs(".pub-meta small", item)?.textContent || "",
        categories: (item.dataset.categories || "").split(/\s+/).filter(Boolean),
      };
      const visible = matchesPublication(publication, q, archiveCategory);
      item.hidden = !visible;
      item.setAttribute("aria-hidden", visible ? "false" : "true");
      if (visible) shown += 1;
    });

    if (archiveEmpty) archiveEmpty.hidden = shown !== 0;
    if (resultCount) resultCount.textContent = `${shown} ${shown === 1 ? "Veröffentlichung" : "Veröffentlichungen"}`;
    if (searchReset) searchReset.hidden = !(archiveSearch?.value || "").trim();

    archiveFilters.forEach(button => {
      const active = button.dataset.filter === archiveCategory;
      button.classList.toggle("active", active);
      button.setAttribute("aria-pressed", String(active));
    });

    if (updateUrl) syncArchiveUrl();
  };

  if (archiveItems.length) {
    const params = new URLSearchParams(location.search);
    const requestedCategory = params.get("thema");
    const validCategories = new Set(archiveFilters.map(button => button.dataset.filter));
    archiveCategory = validCategories.has(requestedCategory) ? requestedCategory : "alle";
    if (archiveSearch && params.get("q")) archiveSearch.value = params.get("q");

    archiveSearch?.addEventListener("input", () => applyArchive(true));
    archiveSearch?.addEventListener("search", () => applyArchive(true));

    archiveFilters.forEach(button => button.addEventListener("click", () => {
      archiveCategory = button.dataset.filter || "alle";
      applyArchive(true);
    }));

    searchReset?.addEventListener("click", () => {
      if (archiveSearch) {
        archiveSearch.value = "";
        archiveSearch.focus();
      }
      applyArchive(true);
    });

    resetFilters?.addEventListener("click", () => {
      archiveCategory = "alle";
      if (archiveSearch) archiveSearch.value = "";
      applyArchive(true);
    });

    applyArchive(false);
    if (location.search && location.hash === "#publikationen") {
      setTimeout(() => qs("#publikationen")?.scrollIntoView({ block: "start" }), 0);
    }
  }

  // Global search, available on every normal page.
  const overlay = qs("[data-search-overlay]");
  const globalInput = qs("[data-global-search]");
  const globalResults = qs("[data-global-results]");
  const globalCount = qs("[data-global-count]");
  const globalFilters = qsa("[data-global-filter]");
  let globalCategory = "alle";

  const renderGlobal = () => {
    if (!globalResults) return;
    const q = globalInput?.value || "";
    const matches = PUBLICATIONS.filter(p => matchesPublication(p, q, globalCategory));
    globalResults.innerHTML = "";

    matches.forEach((p, index) => {
      const link = document.createElement("a");
      link.className = "global-result";
      link.href = p.url;
      link.innerHTML = `
        <span class="global-result-index">${String(index + 1).padStart(2, "0")}</span>
        <span><strong>${escapeHtml(p.title)}</strong><small>${escapeHtml(p.category)} · ${escapeHtml(p.year)}</small></span>
        <span aria-hidden="true">→</span>
      `;
      globalResults.appendChild(link);
    });

    if (!matches.length) {
      const empty = document.createElement("p");
      empty.className = "global-search-empty";
      empty.textContent = "Keine passende Veröffentlichung gefunden.";
      globalResults.appendChild(empty);
    }

    if (globalCount) globalCount.textContent = `${matches.length} ${matches.length === 1 ? "Veröffentlichung" : "Veröffentlichungen"}`;
  };

  function escapeHtml(value) {
    return String(value)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  const openSearch = () => {
    if (!overlay) return;
    overlay.hidden = false;
    document.body.classList.add("search-open");
    globalCategory = "alle";
    globalFilters.forEach(b => {
      const active = b.dataset.globalFilter === "alle";
      b.classList.toggle("active", active);
      b.setAttribute("aria-pressed", String(active));
    });
    renderGlobal();
    setTimeout(() => globalInput?.focus(), 30);
  };

  const closeSearch = () => {
    if (!overlay) return;
    overlay.hidden = true;
    document.body.classList.remove("search-open");
  };

  qsa("[data-search-open]").forEach(button => button.addEventListener("click", openSearch));
  qsa("[data-search-close]").forEach(button => button.addEventListener("click", closeSearch));
  globalInput?.addEventListener("input", renderGlobal);
  globalFilters.forEach(button => button.addEventListener("click", () => {
    globalCategory = button.dataset.globalFilter || "alle";
    globalFilters.forEach(b => {
      const active = b === button;
      b.classList.toggle("active", active);
      b.setAttribute("aria-pressed", String(active));
    });
    renderGlobal();
  }));

  document.addEventListener("keydown", event => {
    if (event.key === "Escape" && overlay && !overlay.hidden) closeSearch();
    if (event.key === "k" && (event.ctrlKey || event.metaKey)) {
      event.preventDefault();
      openSearch();
    }
    if (event.key === "Enter" && overlay && !overlay.hidden && document.activeElement === globalInput) {
      const first = qs(".global-result", globalResults);
      if (first) location.href = first.href;
    }
  });

  // Article-side search.
  qsa("[data-side-search]").forEach(input => {
    const container = input.closest(".archive-side-search");
    const results = qs("[data-side-results]", container);
    const render = () => {
      const q = input.value.trim();
      if (!results) return;
      results.innerHTML = "";
      if (!q) {
        results.innerHTML = '<span class="side-search-hint">Tippe einen Begriff ein oder nutze einen Themenfilter.</span>';
        return;
      }
      const matches = PUBLICATIONS.filter(p => matchesPublication(p, q, "alle")).slice(0, 5);
      if (!matches.length) {
        results.innerHTML = '<span class="side-search-hint">Keine Treffer.</span>';
        return;
      }
      matches.forEach(p => {
        const a = document.createElement("a");
        a.href = p.url;
        a.textContent = p.title;
        results.appendChild(a);
      });
    };
    input.addEventListener("input", render);
    input.addEventListener("search", render);
    render();
  });

  // Reading progress on publication pages.
  const progress = qs("[data-reading-progress] span");
  const article = qs(".article-body");
  if (progress && article) {
    const updateProgress = () => {
      const rect = article.getBoundingClientRect();
      const start = scrollY + rect.top - innerHeight * 0.25;
      const end = start + article.offsetHeight - innerHeight * 0.5;
      const value = Math.max(0, Math.min(1, (scrollY - start) / Math.max(1, end - start)));
      progress.style.transform = `scaleX(${value})`;
    };
    addEventListener("scroll", updateProgress, { passive: true });
    addEventListener("resize", updateProgress);
    updateProgress();
  }

  // Back to top.
  const backtop = qs("[data-backtop]");
  if (backtop) {
    const sync = () => backtop.classList.toggle("show", scrollY > 650);
    addEventListener("scroll", sync, { passive: true });
    sync();
    backtop.addEventListener("click", () => { if (globalThis.KGLenis) globalThis.KGLenis.scrollTo(0, { duration: 1.15, easing: t => 1 - Math.pow(1 - t, 4) }); else scrollTo({ top: 0, behavior: matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" }); });
  }

  // ---------------------------------------------------------------
  // v9 motion layer
  // ---------------------------------------------------------------
  const reducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const finePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;

  // Scroll reveal. If IntersectionObserver is unavailable, reveal immediately.
  const revealItems = qsa("[data-reveal]");
  if (reducedMotion || !("IntersectionObserver" in window)) {
    revealItems.forEach(el => el.classList.add("is-visible"));
  } else {
    const revealObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        revealObserver.unobserve(entry.target);
      });
    }, {
      rootMargin: "0px 0px -8% 0px",
      threshold: 0.08,
    });
    revealItems.forEach(el => revealObserver.observe(el));
  }

  // Header reacts to scroll; it never hides completely.
  const siteHeader = qs(".site-header");
  const syncHeader = () => {
    if (!siteHeader) return;
    siteHeader.classList.toggle("header-scrolled", scrollY > 24);
    document.documentElement.style.setProperty(
      "--scroll-progress",
      String(Math.max(0, Math.min(1, scrollY / Math.max(1, document.documentElement.scrollHeight - innerHeight))))
    );
  };
  addEventListener("scroll", syncHeader, { passive: true });
  syncHeader();

  // Header pointer glow.
  if (siteHeader && finePointer && !reducedMotion) {
    siteHeader.addEventListener("pointermove", event => {
      const rect = siteHeader.getBoundingClientRect();
      const x = ((event.clientX - rect.left) / rect.width) * 100;
      document.documentElement.style.setProperty("--pointer-x", `${x}%`);
    });
  }

  // Hero parallax, intentionally small to avoid motion sickness.
  const parallaxRoot = qs("[data-parallax-root]");
  if (parallaxRoot && finePointer && !reducedMotion) {
    let targetX = 0, targetY = 0, currentX = 0, currentY = 0, raf = 0;

    const renderParallax = () => {
      currentX += (targetX - currentX) * 0.09;
      currentY += (targetY - currentY) * 0.09;
      parallaxRoot.style.setProperty("--hero-mx", currentX.toFixed(3));
      parallaxRoot.style.setProperty("--hero-my", currentY.toFixed(3));
      if (Math.abs(targetX - currentX) > 0.002 || Math.abs(targetY - currentY) > 0.002) {
        raf = requestAnimationFrame(renderParallax);
      } else {
        raf = 0;
      }
    };

    parallaxRoot.addEventListener("pointermove", event => {
      const rect = parallaxRoot.getBoundingClientRect();
      targetX = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
      targetY = ((event.clientY - rect.top) / rect.height - 0.5) * 2;
      if (!raf) raf = requestAnimationFrame(renderParallax);
    });

    parallaxRoot.addEventListener("pointerleave", () => {
      targetX = 0;
      targetY = 0;
      if (!raf) raf = requestAnimationFrame(renderParallax);
    });
  }

  // 3D tilt on featured/high-value cards.
  if (finePointer && !reducedMotion) {
    qsa("[data-tilt]").forEach(card => {
      card.addEventListener("pointermove", event => {
        const rect = card.getBoundingClientRect();
        const px = (event.clientX - rect.left) / rect.width;
        const py = (event.clientY - rect.top) / rect.height;
        const rotateY = (px - 0.5) * 7;
        const rotateX = (0.5 - py) * 6;
        card.classList.add("tilting");
        card.style.transform = `perspective(900px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-3px)`;
      });
      card.addEventListener("pointerleave", () => {
        card.classList.remove("tilting");
        card.style.transform = "";
      });
    });

    // Pointer spotlight on interactive surfaces.
    qsa("[data-glow]").forEach(card => {
      card.addEventListener("pointermove", event => {
        const rect = card.getBoundingClientRect();
        card.style.setProperty("--glow-x", `${event.clientX - rect.left}px`);
        card.style.setProperty("--glow-y", `${event.clientY - rect.top}px`);
      });
    });
  }

  // Count-up facts in the hero.
  const counters = qsa("[data-count]");
  if (!reducedMotion && "IntersectionObserver" in window && counters.length) {
    const counterObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = Number(el.dataset.count || 0);
        const duration = 850;
        const startTime = performance.now();
        const tick = now => {
          const progress = Math.min(1, (now - startTime) / duration);
          const eased = 1 - Math.pow(1 - progress, 3);
          el.textContent = String(Math.round(target * eased));
          if (progress < 1) requestAnimationFrame(tick);
          else el.textContent = String(target);
        };
        requestAnimationFrame(tick);
        counterObserver.unobserve(el);
      });
    }, { threshold: 0.6 });
    counters.forEach(el => {
      el.textContent = "0";
      counterObserver.observe(el);
    });
  }

  // Animate newly visible publication rows after filtering/searching.
  if (archiveItems.length && !reducedMotion) {
    const observer = new MutationObserver(mutations => {
      const changed = new Set();
      mutations.forEach(mutation => {
        if (mutation.type === "attributes" && mutation.attributeName === "hidden") {
          changed.add(mutation.target);
        }
      });
      changed.forEach(item => {
        if (!item.hidden && typeof item.animate === "function") {
          item.animate(
            [
              { opacity: 0, transform: "translateY(10px)" },
              { opacity: 1, transform: "translateY(0)" }
            ],
            { duration: 260, easing: "cubic-bezier(.2,.75,.2,1)" }
          );
        }
      });
    });
    archiveItems.forEach(item => observer.observe(item, { attributes: true, attributeFilter: ["hidden"] }));
  }

  // Section-aware nav state for long home page.
  if (document.body.dataset.page === "home" && "IntersectionObserver" in window) {
    const sectionMap = new Map([
      ["themen", qs('.nav a[href="/Test/#themen"]')],
      ["publikationen", qs('.nav a[href="/Test/#publikationen"]')],
    ]);
    const sections = [...sectionMap.keys()].map(id => document.getElementById(id)).filter(Boolean);
    const sectionObserver = new IntersectionObserver(entries => {
      const visible = entries
        .filter(entry => entry.isIntersecting)
        .sort((a, b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (!visible) return;
      qsa(".nav a").forEach(a => a.removeAttribute("data-section-active"));
      const target = sectionMap.get(visible.target.id);
      if (target) target.setAttribute("data-section-active", "true");
    }, { rootMargin: "-30% 0px -55% 0px", threshold: [0, .1, .3] });
    sections.forEach(section => sectionObserver.observe(section));
  }


  // ---------------------------------------------------------------
  // v12 shared motion layer for all normal pages
  // ---------------------------------------------------------------

  const v12Root = document.documentElement;
  const v12FinePointer = matchMedia("(hover: hover) and (pointer: fine)").matches;
  const v12ReducedMotion = matchMedia("(prefers-reduced-motion: reduce)").matches;

  // Global scroll progress, page signal and side meter.
  const meterLabel = qs(".scroll-meter-label");
  const updateGlobalProgress = () => {
    const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    const value = Math.max(0, Math.min(1, scrollY / max));
    v12Root.style.setProperty("--page-scroll", value.toFixed(4));
    if (meterLabel) meterLabel.textContent = `${Math.round(value * 100)}%`;
  };
  addEventListener("scroll", updateGlobalProgress, { passive: true });
  addEventListener("resize", updateGlobalProgress);
  updateGlobalProgress();

  // Smooth cursor aura. CSS uses the variables so there is no layout work.
  if (v12FinePointer && !v12ReducedMotion) {
    let cx = innerWidth * .5, cy = innerHeight * .5;
    let tx = cx, ty = cy, cursorRaf = 0;
    const renderCursor = () => {
      cx += (tx - cx) * .14;
      cy += (ty - cy) * .14;
      v12Root.style.setProperty("--cursor-x", `${cx.toFixed(1)}px`);
      v12Root.style.setProperty("--cursor-y", `${cy.toFixed(1)}px`);
      if (Math.abs(tx-cx) > .1 || Math.abs(ty-cy) > .1) cursorRaf = requestAnimationFrame(renderCursor);
      else cursorRaf = 0;
    };
    addEventListener("pointermove", event => {
      tx = event.clientX;
      ty = event.clientY;
      v12Root.classList.add("cursor-active");
      if (!cursorRaf) cursorRaf = requestAnimationFrame(renderCursor);
    }, { passive: true });
    document.addEventListener("mouseleave", () => v12Root.classList.remove("cursor-active"));
  }

  // Parallax on all inner page heroes, not only the home page.
  if (v12FinePointer && !v12ReducedMotion) {
    qsa("[data-page-parallax]").forEach(root => {
      root.addEventListener("pointermove", event => {
        const rect = root.getBoundingClientRect();
        const x = ((event.clientX - rect.left) / Math.max(1, rect.width) - .5) * 2;
        const y = ((event.clientY - rect.top) / Math.max(1, rect.height) - .5) * 2;
        root.style.setProperty("--page-parallax-x", x.toFixed(3));
        root.style.setProperty("--page-parallax-y", y.toFixed(3));
      });
      root.addEventListener("pointerleave", () => {
        root.style.setProperty("--page-parallax-x", "0");
        root.style.setProperty("--page-parallax-y", "0");
      });
    });
  }

  // Magnetic movement on a small set of CTA elements. Translate is used so
  // existing transform animations and layout cannot be overwritten.
  if (v12FinePointer && !v12ReducedMotion) {
    qsa("[data-magnetic]").forEach(el => {
      el.addEventListener("pointermove", event => {
        const rect = el.getBoundingClientRect();
        const x = (event.clientX - rect.left - rect.width / 2) * .08;
        const y = (event.clientY - rect.top - rect.height / 2) * .08;
        el.style.translate = `${x.toFixed(1)}px ${y.toFixed(1)}px`;
      });
      el.addEventListener("pointerleave", () => { el.style.translate = ""; });
    });
  }

  // Ripple microinteraction for buttons, filters and document cards.
  if (!v12ReducedMotion) {
    qsa("[data-ripple-target]").forEach(el => {
      el.addEventListener("pointerdown", event => {
        const rect = el.getBoundingClientRect();
        const ripple = document.createElement("span");
        ripple.className = "ui-ripple";
        ripple.style.left = `${event.clientX - rect.left}px`;
        ripple.style.top = `${event.clientY - rect.top}px`;
        el.appendChild(ripple);
        ripple.addEventListener("animationend", () => ripple.remove(), { once: true });
      });
    });
  }

  // Reading focus and the article-side progress rail.
  const readingBlocks = qsa("[data-reading-block]");
  if (readingBlocks.length && "IntersectionObserver" in window) {
    const readingObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        entry.target.classList.toggle("reading-current", entry.isIntersecting);
      });
    }, { rootMargin: "-42% 0px -47% 0px", threshold: 0 });
    readingBlocks.forEach(block => readingObserver.observe(block));
  }

  const progressArticle = qs("[data-article-progress]");
  if (progressArticle) {
    const updateArticleRail = () => {
      const rect = progressArticle.getBoundingClientRect();
      const start = scrollY + rect.top - innerHeight * .22;
      const end = start + progressArticle.offsetHeight - innerHeight * .5;
      const value = Math.max(0, Math.min(1, (scrollY - start) / Math.max(1, end - start)));
      progressArticle.style.setProperty("--article-read", value.toFixed(4));
    };
    addEventListener("scroll", updateArticleRail, { passive: true });
    addEventListener("resize", updateArticleRail);
    updateArticleRail();
  }

  // Pointer spotlight variables on newly added cards and legal sections.
  if (v12FinePointer && !v12ReducedMotion) {
    qsa("[data-lift], [data-glow]").forEach(el => {
      el.addEventListener("pointermove", event => {
        const rect = el.getBoundingClientRect();
        el.style.setProperty("--fx-x", `${event.clientX - rect.left}px`);
        el.style.setProperty("--fx-y", `${event.clientY - rect.top}px`);
      });
    });
  }


  // ---------------------------------------------------------------
  // v13 premium polish
  // ---------------------------------------------------------------

  // Moving navigation indicator. Falls back to the existing nav styling.
  const navBox = qs('.nav');
  const navIndicator = qs('.nav-indicator', navBox || document);
  if (navBox && navIndicator) {
    const navLinks = qsa('a', navBox);
    const activeNav = () => navLinks.find(a => a.matches('[aria-current="page"], [data-section-active="true"]')) || navLinks[0];
    const placeIndicator = link => {
      if (!link || innerWidth <= 780) {
        navBox.style.setProperty('--nav-indicator-opacity', '0');
        return;
      }
      const box = navBox.getBoundingClientRect();
      const rect = link.getBoundingClientRect();
      navBox.style.setProperty('--nav-indicator-x', `${Math.max(0, rect.left - box.left + 8)}px`);
      navBox.style.setProperty('--nav-indicator-w', `${Math.max(18, rect.width - 16)}px`);
      navBox.style.setProperty('--nav-indicator-opacity', '1');
    };
    navLinks.forEach(link => {
      link.addEventListener('pointerenter', () => placeIndicator(link));
      link.addEventListener('focus', () => placeIndicator(link));
    });
    navBox.addEventListener('pointerleave', () => placeIndicator(activeNav()));
    addEventListener('resize', () => placeIndicator(activeNav()));
    setTimeout(() => placeIndicator(activeNav()), 50);

    // Section-active mutations on the home page also move the indicator.
    const navMutation = new MutationObserver(() => placeIndicator(activeNav()));
    navLinks.forEach(link => navMutation.observe(link, { attributes: true, attributeFilter: ['aria-current','data-section-active'] }));
  }

  // Home page section compass.
  const railLinks = qsa('[data-section-link]');
  if (railLinks.length && 'IntersectionObserver' in window) {
    const railSections = railLinks
      .map(link => document.getElementById(link.dataset.sectionLink))
      .filter(Boolean);
    const setRail = id => railLinks.forEach(link => link.classList.toggle('active', link.dataset.sectionLink === id));
    const railObserver = new IntersectionObserver(entries => {
      const visible = entries
        .filter(entry => entry.isIntersecting)
        .sort((a,b) => b.intersectionRatio - a.intersectionRatio)[0];
      if (visible) setRail(visible.target.id);
    }, { rootMargin: '-28% 0px -58% 0px', threshold: [0, .08, .22] });
    railSections.forEach(section => railObserver.observe(section));
  }

  // Article reading minimap follows the currently highlighted paragraph.
  const readingMini = qs('[data-reading-minimap]');
  const readingBlocksV13 = qsa('[data-reading-block]');
  if (readingMini && readingBlocksV13.length) {
    const bars = qsa('[data-reading-index]', readingMini);
    const syncMini = () => {
      let index = readingBlocksV13.findIndex(block => block.classList.contains('reading-current'));
      if (index < 0) {
        const center = innerHeight * .45;
        let best = Infinity;
        readingBlocksV13.forEach((block, i) => {
          const r = block.getBoundingClientRect();
          const d = Math.abs((r.top + r.bottom) / 2 - center);
          if (d < best) { best = d; index = i; }
        });
      }
      bars.forEach((bar, i) => bar.classList.toggle('active', i === index));
    };
    addEventListener('scroll', syncMini, { passive: true });
    addEventListener('resize', syncMini);
    const miniMutation = new MutationObserver(syncMini);
    readingBlocksV13.forEach(block => miniMutation.observe(block, { attributes: true, attributeFilter: ['class'] }));
    syncMini();
  }

  // Tiny parallax on SVG signal field based on scroll, with no layout impact.
  const motionWaves = qsa('.motion-wave');
  if (motionWaves.length && !reducedMotion) {
    const syncWaves = () => {
      const y = Math.max(-12, Math.min(12, scrollY * .015));
      motionWaves.forEach((wave, i) => {
        wave.style.transform = `translate3d(0, ${((i % 2 ? -1 : 1) * y).toFixed(2)}px, 0)`;
      });
    };
    addEventListener('scroll', syncWaves, { passive: true });
    syncWaves();
  }


  // v14 responsive viewport state.
  const syncResponsiveViewport = () => {
    const vv = window.visualViewport;
    const width = Math.round(vv?.width || window.innerWidth);
    const height = Math.round(vv?.height || window.innerHeight);

    document.documentElement.style.setProperty("--app-vh", `${height}px`);
    document.documentElement.style.setProperty("--app-vw", `${width}px`);

    const mode = width < 700 ? "phone" : width < 1100 ? "tablet" : "desktop";
    document.documentElement.dataset.viewport = mode;
    document.documentElement.dataset.orientation = width > height ? "landscape" : "portrait";

    const touch = matchMedia("(pointer: coarse)").matches;
    document.documentElement.classList.toggle("is-touch", touch);

    // If the viewport grows back to desktop, close the temporary mobile menu.
    if (mode === "desktop" && nav && menuButton) {
      nav.classList.remove("open");
      menuButton.setAttribute("aria-expanded", "false");
    }
  };

  syncResponsiveViewport();
  addEventListener("resize", syncResponsiveViewport, { passive: true });
  addEventListener("orientationchange", syncResponsiveViewport, { passive: true });
  if (window.visualViewport) {
    visualViewport.addEventListener("resize", syncResponsiveViewport, { passive: true });
  }


  // ---------------------------------------------------------------
  // v17 interaction-only motion layer
  // Nothing here moves without a user action, scrolling or page load.
  // ---------------------------------------------------------------

  // Page progress follows scroll position only.
  const v17PageProgress = qs(".v17-page-progress span");
  const syncV17Progress = () => {
    if (!v17PageProgress) return;
    const max = Math.max(1, document.documentElement.scrollHeight - innerHeight);
    const ratio = Math.max(0, Math.min(1, scrollY / max));
    v17PageProgress.style.transform = `scaleX(${ratio})`;
  };
  addEventListener("scroll", syncV17Progress, { passive: true });
  addEventListener("resize", syncV17Progress);
  syncV17Progress();

  // Re-run only the active filter chip's small one-shot pop.
  const replayPop = element => {
    if (!element || reducedMotion) return;
    element.style.animation = "none";
    element.offsetHeight;
    element.style.animation = "";
  };

  qsa("[data-filter], [data-global-filter]").forEach(button => {
    button.addEventListener("click", () => replayPop(button));
  });

  // Search results get a one-shot stagger after being rendered.
  const animateSearchResults = root => {
    if (!root || reducedMotion) return;
    qsa(".global-result", root).forEach((item, index) => {
      item.classList.remove("result-enter");
      item.style.animationDelay = `${Math.min(index, 8) * 28}ms`;
      item.offsetHeight;
      item.classList.add("result-enter");
    });
  };

  if (globalInput && globalResults) {
    globalInput.addEventListener("input", () => {
      requestAnimationFrame(() => animateSearchResults(globalResults));
    });
  }

  globalFilters.forEach(button => button.addEventListener("click", () => {
    requestAnimationFrame(() => animateSearchResults(globalResults));
  }));

  // Section rules draw once on first entry.
  if ("IntersectionObserver" in window) {
    const v17Rules = qsa(".v17-section-rule");
    const ruleObserver = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) return;
        entry.target.classList.add("is-visible");
        ruleObserver.unobserve(entry.target);
      });
    }, { threshold: .35 });
    v17Rules.forEach(rule => ruleObserver.observe(rule));
  } else {
    qsa(".v17-section-rule").forEach(rule => rule.classList.add("is-visible"));
  }

  // Click ripple for buttons, only when clicked.
  qsa(".button, .filter, .search-chip, .header-search, .menu").forEach(button => {
    button.addEventListener("pointerdown", event => {
      if (reducedMotion) return;
      const rect = button.getBoundingClientRect();
      const ripple = document.createElement("span");
      ripple.className = "v17-ripple";
      const size = Math.max(rect.width, rect.height) * 1.4;
      ripple.style.width = ripple.style.height = `${size}px`;
      ripple.style.left = `${event.clientX - rect.left - size / 2}px`;
      ripple.style.top = `${event.clientY - rect.top - size / 2}px`;
      button.appendChild(ripple);
      ripple.animate(
        [
          { opacity: .28, transform: "scale(.25)" },
          { opacity: 0, transform: "scale(1)" }
        ],
        { duration: 420, easing: "ease-out" }
      ).finished.finally(() => ripple.remove());
    });
  });

})();
