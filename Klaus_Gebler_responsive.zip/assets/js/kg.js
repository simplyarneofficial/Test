(function(){
var html=document.documentElement,qs=function(s,r){return(r||document).querySelector(s);},qa=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s));};
var still=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine)').matches,ss=null;
try{ss=sessionStorage;}catch(e){}
function store(k,v){try{if(v===undefined)return ss.getItem(k);ss.setItem(k,v);}catch(e){}}
// Menü: Wörter maskieren, Fußzeile
var nav=qs('[data-nav]');
if(nav){qa('a',nav).forEach(function(a,i){a.style.setProperty('--i',i);a.innerHTML='<span class="ml"><span>'+a.innerHTML.trim()+'</span></span>';});
  var f=document.createElement('div');f.className='nav-foot';f.innerHTML='<a href="/impressum/">Impressum</a><a href="/datenschutz/">Datenschutz</a><span>Physik und Weltbild</span>';nav.appendChild(f);}
var bt=qs('[data-backtop]');
function bsync(){if(bt)bt.classList.toggle('kg-show',scrollY>700);}addEventListener('scroll',bsync,{passive:true});bsync();
var gsap=window.gsap,ST=window.ScrollTrigger;
if(!gsap||!ST||still){html.classList.remove('kg-i');return;}
gsap.registerPlugin(ST);
var lenis=null,vel=0;
if(window.Lenis){
  lenis=new Lenis({lerp:.09});
  lenis.on('scroll',function(e){vel=e.velocity;ST.update();});
  gsap.ticker.add(function(t){lenis.raf(t*1000);});gsap.ticker.lagSmoothing(0);
  qa('.search-panel,[data-nav]').forEach(function(e){e.setAttribute('data-lenis-prevent','');});
  if(nav)new MutationObserver(function(){nav.classList.contains('open')?lenis.stop():lenis.start();}).observe(nav,{attributes:true,attributeFilter:['class']});
  var so=qs('[data-search-overlay]');
  if(so)new MutationObserver(function(){so.hidden?lenis.start():lenis.stop();}).observe(so,{attributes:true,attributeFilter:['hidden']});
}
window.KGLenis=lenis;
gsap.ticker.add(function(){vel*=.92;});
// Keep the back-to-top control in sync with the active smooth-scroll engine.
// Close the mobile navigation with Escape and return focus to its trigger.
if(nav){document.addEventListener('keydown',function(e){if(e.key==='Escape'&&nav.classList.contains('open')){nav.classList.remove('open');var mb=qs('[data-menu]');if(mb){mb.setAttribute('aria-expanded','false');mb.focus();}}});}

// Seitenübergang (Abgang) und interne Anker
document.addEventListener('click',function(e){
  var a=e.target.closest&&e.target.closest('a[href]');if(!a||e.defaultPrevented||e.metaKey||e.ctrlKey||e.shiftKey||a.target==='_blank'||a.hasAttribute('download'))return;
  var u;try{u=new URL(a.href,location.href);}catch(x){return;}
  if(u.origin!==location.origin||/\.(pdf|zip|jpg|png)$/i.test(u.pathname))return;
  if(u.pathname===location.pathname&&u.hash&&lenis){var t=qs(u.hash);if(t){e.preventDefault();lenis.scrollTo(t,{offset:-84,duration:1.4});}return;}
  if(u.pathname===location.pathname)return;
  e.preventDefault();var c=document.createElement('div');c.className='kg-cover';document.body.appendChild(c);
  gsap.set(c,{yPercent:100});
  gsap.to(c,{yPercent:0,duration:.6,ease:'power4.inOut',onComplete:function(){store('kg-w','1');location.href=u.href;}});
});
addEventListener('pageshow',function(e){if(e.persisted)qa('.kg-cover').forEach(function(c){c.remove();});});

// Text in Zeilen mit Maske
function lines(el){
  if(!el||el.dataset.kg)return[];el.dataset.kg='1';
  el.setAttribute('aria-label',el.textContent.replace(/\s+/g,' ').trim());
  var g=[[]];Array.prototype.slice.call(el.childNodes).forEach(function(n){if(n.nodeName==='BR')g.push([]);else g[g.length-1].push(n);});
  el.textContent='';var ins=[];
  g.forEach(function(x){if(!x.some(function(n){return n.textContent.trim();}))return;
    var l=document.createElement('span');l.className='kg-line';l.setAttribute('aria-hidden','true');
    var i=document.createElement('span');i.className='kg-in';x.forEach(function(n){i.appendChild(n);});l.appendChild(i);el.appendChild(l);ins.push(i);});
  return ins;
}

// Intro: zweigeteilter Vorhang, einmal pro Sitzung
var hero=qs('.home-hero'),D=0;
if(hero&&!store('kg-i')){
  store('kg-i','1');D=1.9;
  var iv=document.createElement('div');iv.className='kg-intro';iv.setAttribute('aria-hidden','true');
  iv.innerHTML='<i class="a"></i><i class="b"></i><div class="t"><div>KG<small>PHYSIK UND WELTBILD</small></div></div>';
  document.body.appendChild(iv);html.classList.remove('kg-i');if(lenis)lenis.stop();
  var tx=qs('.t>div',iv);
  gsap.timeline({onComplete:function(){iv.remove();if(lenis&&!(nav&&nav.classList.contains('open')))lenis.start();}})
    .from(tx,{yPercent:40,opacity:0,duration:.9,ease:'power4.out'})
    .to(tx,{yPercent:-30,opacity:0,duration:.5,ease:'power3.in'},'+=.25')
    .to(qs('.a',iv),{yPercent:-100,duration:.95,ease:'power4.inOut'},'-=.1')
    .to(qs('.b',iv),{yPercent:100,duration:.95,ease:'power4.inOut'},'<');
}else html.classList.remove('kg-i');

// Hero
if(hero){
  var h1=qs('h1',hero),ins=lines(h1);
  if(ins.length)gsap.set(ins,{yPercent:115,rotate:3});
  gsap.set('.kicker,.hero-lead,.hero-actions .button,.hero-facts li,.hero-feature',{opacity:0,y:36});
  var tl=gsap.timeline({delay:D+.1});
  tl.to('.kicker',{opacity:1,y:0,duration:.8,ease:'power3.out'})
    .to(ins,{yPercent:0,rotate:0,duration:1.3,ease:'expo.out',stagger:.14},'-=.5')
    .to('.hero-lead',{opacity:1,y:0,duration:.9,ease:'power3.out'},'-=.8')
    .to('.hero-actions .button',{opacity:1,y:0,duration:.8,ease:'power3.out',stagger:.1},'-=.7')
    .to('.hero-facts li',{opacity:1,y:0,duration:.8,ease:'power3.out',stagger:.1},'-=.6')
    .to('.hero-feature',{opacity:1,y:0,duration:1.1,ease:'power3.out'},'-=1.1');
  var img=qs('.feature-cover img',hero);
  if(img)gsap.fromTo(img,{scale:1.25,yPercent:-6},{scale:1,yPercent:6,ease:'none',scrollTrigger:{trigger:hero,start:'top top',end:'bottom top',scrub:true}});
  gsap.to('.hero-inner',{yPercent:-6,opacity:.2,ease:'none',scrollTrigger:{trigger:hero,start:'60% top',end:'bottom top',scrub:true}});
  // Sternenfeld
  var cv=document.createElement('canvas');cv.id='kg-stars';cv.setAttribute('aria-hidden','true');hero.insertBefore(cv,hero.firstChild);
  var c=cv.getContext('2d'),W,H,D2,pts=[],mx=-999,my=-999,on=true;
  function size(){D2=Math.min(devicePixelRatio||1,2);W=hero.clientWidth;H=hero.clientHeight;cv.width=W*D2;cv.height=H*D2;c.setTransform(D2,0,0,D2,0,0);var n=Math.round(Math.min(100,W*H/16000));pts=[];for(var i=0;i<n;i++)pts.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.3,vy:(Math.random()-.5)*.3,r:Math.random()*1.5+.5,a:Math.random()<.18});}
  size();addEventListener('resize',size);
  hero.addEventListener('pointermove',function(e){var r=hero.getBoundingClientRect();mx=e.clientX-r.left;my=e.clientY-r.top;});
  hero.addEventListener('pointerleave',function(){mx=my=-999;});
  ST.create({trigger:hero,start:'top bottom',end:'bottom top',onToggle:function(s){on=s.isActive;}});
  var LD=W<700?7000:12000;
  gsap.ticker.add(function(){
    if(!on)return;c.clearRect(0,0,W,H);var i,j,p,q,dx,dy,d;
    for(i=0;i<pts.length;i++){p=pts[i];dx=p.x-mx;dy=p.y-my;d=dx*dx+dy*dy;
      if(d<26000){var m=Math.sqrt(d)||1,f=(1-d/26000)*.5;p.vx+=dx/m*f;p.vy+=dy/m*f;}
      p.vx*=.985;p.vy*=.985;p.x+=p.vx;p.y+=p.vy+vel*.01;
      if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;
      c.fillStyle=p.a?'rgba(205,187,149,.9)':'rgba(190,200,205,.75)';c.beginPath();c.arc(p.x,p.y,p.r,0,6.3);c.fill();
      for(j=i+1;j<pts.length;j++){q=pts[j];dx=p.x-q.x;dy=p.y-q.y;d=dx*dx+dy*dy;if(d<LD){c.strokeStyle='rgba(190,200,205,'+(.18*(1-d/LD))+')';c.lineWidth=.7;c.beginPath();c.moveTo(p.x,p.y);c.lineTo(q.x,q.y);c.stroke();}}
    }
  });
  // Laufband
  var mq=document.createElement('div');mq.className='kg-marq';mq.setAttribute('aria-hidden','true');
  var inn=document.createElement('div'),t='';['Beobachten','Zweifeln','Weiterdenken','Relativität','Kosmologie','Weltbild'].forEach(function(w){t+=w+'<i>✦</i>';});
  inn.innerHTML=t+t+t+t;mq.appendChild(inn);hero.parentNode.insertBefore(mq,hero.nextSibling);
  var x=0,bo=0;gsap.ticker.add(function(){bo+=(Math.abs(vel)-bo)*.1;x-=.8+bo*1.1;var w=inn.scrollWidth/2;if(-x>w)x+=w;inn.style.transform='translateX('+x+'px) skewX('+gsap.utils.clamp(-9,9,vel*-.35)+'deg)';});
}

// Seitenkopf Unterseiten
var ph=qs('.page-hero h1,.legal-hero h1');
if(ph){var pi=lines(ph);gsap.set(pi,{yPercent:115,rotate:2});
  gsap.set('.breadcrumb,.page-meta,.lead,.legal-hero-inner>p,.legal-hero .eyebrow',{opacity:0,y:24});
  gsap.timeline({delay:.15}).to('.breadcrumb,.legal-hero .eyebrow',{opacity:1,y:0,duration:.7,ease:'power3.out'}).to(pi,{yPercent:0,rotate:0,duration:1.2,ease:'expo.out',stagger:.1},'-=.4')
   .to('.page-meta,.lead,.legal-hero-inner>p',{opacity:1,y:0,duration:.8,ease:'power3.out',stagger:.1},'-=.8');}

// Überschriften der Abschnitte
qa('main h2,.article-body h2,.legal-card h2').forEach(function(h){
  if(h.closest('.search-panel')||h.closest('.hero-feature'))return;
  var i=lines(h);if(!i.length)return;gsap.set(i,{yPercent:115});
  ST.create({trigger:h,start:'top 90%',once:true,onEnter:function(){gsap.to(i,{yPercent:0,duration:1.1,ease:'expo.out',stagger:.1});}});
});
qa('.eyebrow').forEach(function(e){if(e.closest('.legal-hero'))return;gsap.from(e,{opacity:0,x:-20,duration:.8,ease:'power3.out',scrollTrigger:{trigger:e,start:'top 92%',once:true}});});

// Einleitungstexte Wort für Wort
qa('.section-top p,.archive-head p').forEach(function(p){
  if(p.children.length||p.dataset.kg)return;p.dataset.kg='1';var t=p.textContent.trim();p.textContent='';
  var ws=t.split(/\s+/).map(function(w){var e=document.createElement('span');e.className='kg-w';e.textContent=w+' ';p.appendChild(e);return e;});
  gsap.to(ws,{opacity:1,ease:'none',stagger:.4,scrollTrigger:{trigger:p,start:'top 88%',end:'bottom 58%',scrub:true}});
});

// Karten, Kacheln, Zeilen
function rise(sel,o){var els=qa(sel);if(!els.length)return;gsap.set(els,{opacity:0,y:o.y||60,scale:o.s||1});
  ST.batch(els,{start:'top 92%',once:true,onEnter:function(b){gsap.to(b,{opacity:1,y:0,scale:1,duration:1,ease:'expo.out',stagger:o.st||.1,overwrite:true});}});}
rise('.statement',{y:80,s:.96,st:.18});
rise('.topic-card',{y:90,s:.94,st:.12});
rise('.pub',{y:36,st:.06});
rise('.side-card',{y:40,st:.1});
rise('.next-prev a',{y:50,st:.12});
if(qs('.archive-band-inner'))gsap.from('.archive-band-inner>*',{opacity:0,y:40,duration:1,ease:'expo.out',stagger:.12,scrollTrigger:{trigger:'.archive-band',start:'top 80%',once:true}});
qa('.statement-grid .statement').forEach(function(s,i){gsap.to(s,{y:i%2?-24:24,ease:'none',scrollTrigger:{trigger:s,start:'top bottom',end:'bottom top',scrub:true}});});

// Bilder und Absätze im Artikel
qa('.article-body img,.feature-cover').forEach(function(im){if(hero&&hero.contains(im))return;
  gsap.fromTo(im,{clipPath:'inset(12% 8% 12% 8% round 22px)',scale:1.05},{clipPath:'inset(0% 0% 0% 0% round 20px)',scale:1,ease:'none',scrollTrigger:{trigger:im,start:'top 94%',end:'top 50%',scrub:true}});});
qa('.article-opening').forEach(function(p){gsap.from(p,{opacity:0,y:30,duration:1,ease:'expo.out',delay:.5});});
qa('.doc-link').forEach(function(d){gsap.from(d,{opacity:0,y:30,duration:.8,ease:'power3.out',scrollTrigger:{trigger:d,start:'top 92%',once:true}});});

// Magnetische Buttons
if(fine)qa('.hero-actions .button,.header-search,.menu,.archive-band-inner a,.feature-link').forEach(function(b){
  b.addEventListener('pointermove',function(e){var r=b.getBoundingClientRect();gsap.to(b,{x:(e.clientX-r.left-r.width/2)*.28,y:(e.clientY-r.top-r.height/2)*.4,duration:.35,ease:'power3.out'});});
  b.addEventListener('pointerleave',function(){gsap.to(b,{x:0,y:0,duration:.8,ease:'elastic.out(1,.4)'});});
});
addEventListener('load',function(){ST.refresh();});
setTimeout(function(){if(store('kg-w'))store('kg-w','');},1500);
})();
