# Animation tools

This static HTML website uses the following libraries locally:

- GSAP: https://github.com/greensock/GSAP
- ScrollTrigger: distributed with GSAP and used for scroll-linked animations.
- Lenis: https://github.com/darkroomengineering/lenis

React Bits: https://github.com/DavidHDev/react-bits

React Bits is a React component collection. This website is currently plain HTML, CSS, and JavaScript, so importing React Bits directly would require migrating parts of the site to React. It has therefore been documented as a future option rather than adding an unused framework and increasing page weight.
